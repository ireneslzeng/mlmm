library(testthat)
library(Rcpp)
library(mlmm)

test_check("mlmm")
